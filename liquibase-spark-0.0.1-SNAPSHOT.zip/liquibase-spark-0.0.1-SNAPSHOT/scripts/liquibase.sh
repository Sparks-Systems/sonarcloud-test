#!/bin/bash
BASEDIR=$(dirname "$0")
export LIQUIBASE_HOME="$BASEDIR"/../jars
export PATH=$PATH:$LIQUIBASE_HOME
echo "Starting Liquibase..."
echo $LIQUIBASE_HOME
java -jar "$LIQUIBASE_HOME/internal/lib/liquibase-core-4.19.0.jar" \
--changelog-file="$BASEDIR"/../liquibase/changelog-root.yaml \
--username=$DB_USER \
--password=$DB_PASSWORD \
--url=$DB_URL \
--driver=org.postgresql.Driver \
--classpath=$LIQUIBASE_HOME/internal/lib/postgresql-42.2.5.jar \
--defaultsFile= $LIQUIBASE_PROPERTIES \
$COMMAND