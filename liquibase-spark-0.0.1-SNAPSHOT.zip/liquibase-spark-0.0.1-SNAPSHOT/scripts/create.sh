#!/bin/bash
export LIQUIBASE_HOME=$PWD/jars
export PATH=$PATH:$LIQUIBASE_HOME
echo "Initializing database with the following sql commands:"
java -jar $LIQUIBASE_HOME/internal/lib/liquibase-core-4.19.0.jar \
--changelog-file=./liquibase/changelog-root \
--username=$DB_USER \
--password=$DB_PASSWORD \
--url=$DB_URL \
--driver=org.postgresql.Driver \
updatesql
java -jar $LIQUIBASE_HOME/internal/libliquibase-core-4.19.0.jar \
--changelog-file=/liquibase/changelog-root \
--username=$DB_USER \
--password=$DB_PASSWORD \
--url=$DB_URL \
--driver=org.postgresql.Driver \
update

#java -jar /mnt/c/Users/david.cai/dev/poc/liquibase-spark/target/liquibase/internal/lib/liquibase-core-4.19.0.jar
#
#
#java -cp cygdrive/c/Users/david.cai/dev/poc/liquibase-spark\target\lib\liquibase-core-4.19.0.jar liquibase.integration.commandline.LiquibaseCommandLine
#java -cp /mnt/c/Users/david.cai/dev/p oc/liquibase-spark/target/lib/* liquibase.integration.commandline.LiquibaseCommandLine
#java -cp /mnt/c/Users/david.cai/dev/poc/liquibase-spark/target/internal/lib/liquibase-core-4.19.0.jar:/mnt/c/Users/david.cai/dev/poc/liquibase-spark/target/internal/lib/picocli-4.3.1.jar liquibase.integration.commandline.LiquibaseCommandLine
#java -jar $LIQUIBASE_HOME/internal/lib/liquibase-core.jar
#--changelog-file=./liquibase/changelog-root \
#--username=$DB_USER \
#--password=$DB_PASSWORD \
#--url=$DB_URL \
#--driver=org.postgresql.Driver \
#updatesql

#export LIQUIBASE_HOME=$PWD/target/liquibase
#export PATH=$PATH:$LIQUIBASE_HOME
#
#psql -p 5432 -U postgres -h localhost -v tablespace_name=main_tablespace -v tablespace_directory="'/main_tablespace'" -v db_name=main_db < main_initial_ddl.sql