#!/bin/bash
export LIQUIBASE_HOME_TEST=$PWD/lib
export PATH=$PATH:$LIQUIBASE_HOME
echo "Initializing database with the following sql commands:"
cd ..
java -jar $LIQUIBASE_HOME/liquibase-core-4.19.0.jar \
--changelog-file=./liquibase/changelog-root \
--username=$DB_USER \
--password=$DB_PASSWORD \
--url=$DB_URL \
--driver=org.postgresql.Driver \
updatesql
java -jar $LIQUIBASE_HOME/liquibase-core-4.19.0.jar \
--changelog-file=./liquibase/changelog-root \
--username=$DB_USER \
--password=$DB_PASSWORD \
--url=$DB_URL \
--driver=org.postgresql.Driver \
update


#java -jar $LIQUIBASE_HOME/internal/lib/liquibase-core.jar
#--changelog-file=./liquibase/changelog-root \
#--username=$DB_USER \
#--password=$DB_PASSWORD \
#--url=$DB_URL \
#--driver=org.postgresql.Driver \
#updatesql