#!/bin/bash
export LIQUIBASE_HOME=./liquibaseyml
export PATH=$PATH:$LIQUIBASE_HOME
echo "Initializing database with the following sql commands:"
cd ..
liquibase
--changelog-file=./liquibase/changelog-root \
--username=$DB_USER \
--password=$DB_PASSWORD \
--url=$DB_URL \
--driver=org.postgresql.Driver \
updatesql
liquibase
--changelog-file=./liquibase/changelog-root \
--username=$DB_USER \
--password=$DB_PASSWORD \
--url=$DB_URL \
--driver=org.postgresql.Driver \
update