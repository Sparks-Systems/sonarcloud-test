ssh david.cai@sparksystems.sg@pisg1017.sg1.sparksystems.sg -L 8888:UDSG1001.sg1.sparksystems.sg:30101

ssh david.cai@sparksystems.sg@pisg1017.sg1.sparksystems.sg -L 8889:PDSG1000.sg1.sparksystems.sg:30101

ssh david.cai@sparksystems.sg@pisg1017.sg1.sparksystems.sg -L 8889:PDTY3000.ty3.sparksystems.sg:30101