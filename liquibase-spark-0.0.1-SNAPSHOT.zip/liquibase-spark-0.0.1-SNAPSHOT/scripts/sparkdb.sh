#!/bin/bash
BASEDIR=$(dirname "$0")
echo "Environment is $1"
echo "Liquibase Command is $2"

if [ "$1" == "local" ]
then
    mvn clean install -P "$1"
    mvn liquibase:"$2"
else
#    set static environment variables based on config folder
    source "$BASEDIR"/liquibase.sh
    export LIQUIBASE_PROPERTIES="$BASEDIR"/../config/"$1".properties
fi