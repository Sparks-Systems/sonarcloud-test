#!/usr/bin/env bash
liquibase --url=jdbc:postgresql://DDSGF001.sgf.sparksystems.sg:30101/liquibase_db --username=postgres --password=Spark123! \
--referenceUrl=jdbc:postgresql://localhost:5432/"$1" --referenceUsername=postgres --referencePassword=postgres \
--schemas=fx \
--changelog-file=liquibase/diff/output/local/"$1".sql diff-changelog
