#!/usr/bin/env bash
liquibase --url=jdbc:postgresql://localhost:8888/test_liquibase_db --username=postgres --password=Sp@rKl1ng123! \
--referenceUrl=jdbc:postgresql://localhost:8889/"$1" --referenceUsername=postgres --referencePassword=Spark123! \
--schemas=fx \
--changelog-file=liquibase/diff/output/ty/"$1".yaml diff-changelog