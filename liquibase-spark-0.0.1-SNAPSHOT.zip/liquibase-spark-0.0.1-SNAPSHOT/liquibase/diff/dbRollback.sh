liquibase --url=jdbc:postgresql://localhost:8888/test_liquibase_db?currentSchema=test2 --username=postgres --password=Sp@rKl1ng123! \
--changelog-file=liquibase/changelog-root.yaml rollback-count 1
