liquibase snapshot --snapshotFormat=yml --url=jdbc:postgresql://localhost:8888/test_liquibase_db --username=postgres --password=Sp@rKl1ng123! --output-file=liquibase/diff/output/currentSnapshot.json --schemas=fx

liquibase --url=jdbc:postgresql://localhost:8888/preprod_src_20221110_db --username=postgres --password=Sp@rKl1ng123! \
--referenceUrl=jdbc:postgresql://localhost:8888/test_liquibase_db --referenceUsername=postgres --referencePassword=Sp@rKl1ng123! \
--schemas=fx \
--output-file=liquibase/diff/output/diff.yaml diff
liquibase --url=jdbc:postgresql://localhost:8888/preprod_src_20221110_db --username=postgres --password=Sp@rKl1ng123! \
--referenceUrl=jdbc:postgresql://localhost:8888/test_liquibase_db --referenceUsername=postgres --referencePassword=Sp@rKl1ng123! \
--schemas=fx \
--changelog-file=liquibase/diff/output/diffChangelog.yaml diff-changelog
