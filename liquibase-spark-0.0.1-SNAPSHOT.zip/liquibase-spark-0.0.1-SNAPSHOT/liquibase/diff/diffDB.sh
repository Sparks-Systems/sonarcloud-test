liquibase snapshot --snapshotFormat=yml --url=jdbc:postgresql://localhost:8888/test_liquibase_db --username=postgres --password=Sp@rKl1ng123! --output-file=liquibase/diff/output/currentSnapshot.yaml --schemas=fx

liquibase --url=jdbc:postgresql://localhost:8888/preprod_src_20221110_db --username=postgres --password=Sp@rKl1ng123! \
--referenceUrl=jdbc:postgresql://localhost:8888/test_liquibase_db --referenceUsername=postgres --referencePassword=Sp@rKl1ng123! \
--schemas=fx \
--output-file=liquibase/diff/output/diff.yaml diff
liquibase --url=jdbc:postgresql://localhost:8888/preprod_src_20221110_db --username=postgres --password=Sp@rKl1ng123! \
--referenceUrl=jdbc:postgresql://localhost:8888/test_liquibase_db --referenceUsername=postgres --referencePassword=Sp@rKl1ng123! \
--schemas=fx \
--changelog-file=liquibase/diff/output/diffChangelog.yaml diff-changelog

liquibase --url=jdbc:postgresql://localhost:8888/test_liquibase_db --username=postgres --password=Sp@rKl1ng123! \
--referenceUrl=jdbc:postgresql://localhost:8888/demo_ctbctp_db --referenceUsername=postgres --referencePassword=Sp@rKl1ng123! \
--schemas=fx \
--changelog-file=liquibase/diff/output/diffChangelog.yaml diff-changelog



liquibase --url=jdbc:postgresql://localhost:8888/test_liquibase_db --username=postgres --password=Sp@rKl1ng123! \
--referenceUrl=jdbc:postgresql://DDSGF001.sgf.sparksystems.sg:30101/liquibase_db --referenceUsername=postgres --referencePassword=Spark123! \
--schemas=fx \
--changelog-file=liquibase/diff/output/diffChangelog.yaml diff-changelog


# Production databases

#dym_db
liquibase --url=jdbc:postgresql://localhost:8888/test_liquibase_db --username=postgres --password=Sp@rKl1ng123! \
--referenceUrl=jdbc:postgresql://localhost:8889/dym_db --referenceUsername=postgres --referencePassword=Spark123! \
--schemas=fx \
--changelog-file=liquibase/diff/output/dym_db_Changelog.yaml diff-changelog


#kgi_db
liquibase --url=jdbc:postgresql://localhost:8888/test_liquibase_db --username=postgres --password=Sp@rKl1ng123! \
--referenceUrl=jdbc:postgresql://localhost:8889/kgi_db --referenceUsername=postgres --referencePassword=Spark123! \
--schemas=fx \
--changelog-file=liquibase/diff/output/kgi_db_Changelog.yaml diff-changelog