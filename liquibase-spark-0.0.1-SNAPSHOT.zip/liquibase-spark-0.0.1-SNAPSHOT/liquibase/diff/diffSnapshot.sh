liquibase snapshot --snapshotFormat=yml --url=jdbc:postgresql://localhost:8888/test_liquibase_db --username=postgres --password=Sp@rKl1ng123! --output-file=liquibase/diff/output/currentSnapshot.yaml --schemas=test2

liquibase --url=jdbc:postgresql://localhost:8888/test_liquibase_db --username=postgres --password=Sp@rKl1ng123! --referenceUrl=offline:postgresql?snapshot=liquibase/diff/output/currentSnapshot.yaml --schemas=test2 --output-file=liquibase/diff/output/diff.yaml diff
liquibase --url=jdbc:postgresql://localhost:8888/test_liquibase_db --username=postgres --password=Sp@rKl1ng123! --referenceUrl=offline:postgresql?snapshot=liquibase/diff/output/currentSnapshot.yaml --schemas=test2 --changelog-file=liquibase/diff/output/diffChangelog.yaml diff-changelog
